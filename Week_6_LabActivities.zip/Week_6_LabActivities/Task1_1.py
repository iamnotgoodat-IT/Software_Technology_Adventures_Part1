# Task 1.1
#loading an image
import matplotlib.pyplot as plt
# example of loading an image with the Keras API
from keras.preprocessing.image import load_img
# load the image
img_path = r'E:\University\Semester 2\Software Technology (Softek)\Week_4_Lab_Activities\Assets\Insects\insectgammar.PNG'
img = load_img(img_path)
print(type(img))
print(img.format)
print(img.mode)
print(img.size)
# show the image using matplotlib
plt.imshow(img)
plt.axis('off') # Turn off axis labels
plt.show()